﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CusWebApp
{
    public partial class Login : System.Web.UI.Page
    {
        //Variable declaring
        static SqlConnection conn;

        static string url = "";

        //Page load method
        protected void Page_Load(object sender, EventArgs e)
        {
            url = Request.QueryString["url"];

            if (!IsPostBack)
            {
                if (Session["UserID"] != null && Session["DesUName"] != null)
                {
                    if (url != "")
                    {
                        Server.Transfer("~/" + url + "", true);
                    }
                }
            }
        }

        //Login button click event
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            System.Threading.Thread.Sleep(4000);

            conn = DB_Connect.GetConnection();
            string mLoginName = TxtUName.Text;
            string mLoginPassword = TxtPW.Text;

            mLoginPassword = Common.Encrypt(mLoginPassword);

            if (conn.State.ToString() == "Closed")
            {
                conn.Open();
            }
            string sql = " EXEC [CusReg].[dbo].[procCusReg] 0,'" + mLoginName + "','" + mLoginPassword + "','','','','' ";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();

            if (sdr.Read())
            {
                Session["LoggedIn"] = "true";
                Session["UserID"] = sdr["UserID"].ToString();
                Session["DesUName"] = sdr["UserName"].ToString();

                if (url != "" && url != null)
                {
                    Server.Transfer("~/" + url + "", true);
                }

            }
            else
            {
                Session["LoggedIn"] = "false";
            }
            sdr.Close();

            conn.Close();
        }
    }
}