﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;

/// <summary>
/// Password Encryp and Decrypt methods
/// </summary>
public class Common
{
    public Common()
    {
    }

    //Password Encrypt method
    public static string Encrypt(string modINDATA)
    {
        long x = 0;
        string strEncrypt = "";

        if ((modINDATA.Length) != 0)
            for (int i = 0; i < (modINDATA.Length); i++)
            {

                x = (long)System.Text.Encoding.ASCII.GetBytes(modINDATA.Substring(i, 1))[0] + 402;

                while (x > 254)
                {
                    x = (x - 254);
                }

                strEncrypt = strEncrypt + Convert.ToChar(x);

            }
        return (strEncrypt);
    }

    //Password Decrypt method
    public static string Decrypt(string modINDATA)
    {
        long x = 0;
        string strEncrypt = "";

        if ((modINDATA.Length) != 0)
        {
            for (int i = 0; i < (modINDATA.Length); i++)
            {
                x = 0;
                x = (long)System.Text.Encoding.ASCII.GetBytes(modINDATA.Substring(i, 1))[0];
                x = x - 402;
                while (x < 1)
                {
                    x = (x + 254);
                }

                strEncrypt = strEncrypt + Convert.ToChar(x);

            }
        }
        return (strEncrypt);
    }
}
