﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CusWebApp
{
    public partial class CusList : System.Web.UI.Page
    {
        //Connection String from web.config and DB_Connect class File
        SqlConnection conn = DB_Connect.GetConnection();

        //Variable declaring
        static int userid = 0;
        static string url = "CusList.aspx";

        //Page load method
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LblUserID.Text = "";
                userid = Convert.ToInt32(Session["UserID"]);

                LblUserID.Text = Convert.ToString(userid);

                if (LblUserID.Text == "" || LblUserID.Text == "0")
                {
                    Server.Transfer("~/Login.aspx?url=" + url + "", true);
                }

                if (Session["UserID"].ToString() == null)
                {
                    Server.Transfer("~/Login.aspx?url=" + url + "", true);
                }
            }
        }

        //Search button click event
        protected void BtnSearch_Click(object sender, EventArgs e)
        {
            if (TxtCusName.Text != "")
            {
                //Call to Bind Gridview
                BindGvCusList();
            }
        }

        //Bind Gridview method
        private void BindGvCusList()
        {
            if (conn.State.ToString() == "Closed")
            {
                conn.Open();
            }

            string sql = " EXEC [CusReg].[dbo].[procCusListWithEdit] 0,'" + TxtCusName.Text.Trim() + "','','','','',''";

            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);

            using (DataTable dt = new DataTable())
            {
                sda.Fill(dt);
                GvCusList.DataSource = dt;
                GvCusList.DataBind();
            }
            conn.Close();
        }

        //Refresh button click event
        protected void BtnReset_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }

        //Gridview RowEditing event
        protected void GvCusList_RowEditing(object sender, GridViewEditEventArgs e)
        {
            //NewEditIndex property used to determine the index of the row being edited.  
            GvCusList.EditIndex = e.NewEditIndex;
            BindGvCusList();
        }

        //Gridview RowCancelingEdit event
        protected void GvCusList_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            //Setting the EditIndex property to -1 to cancel the Edit mode in Gridvie
            GvCusList.EditIndex = -1;
            BindGvCusList();
        }

        //Gridview RowUpdating event
        protected void GvCusList_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            //Finding the controls from Gridview for the row which is going to update 
            Label LblCusIDD = GvCusList.Rows[e.RowIndex].FindControl("LblCusIDD") as Label;
            TextBox TxtName = GvCusList.Rows[e.RowIndex].FindControl("TxtName") as TextBox;
            TextBox TxtPhnno = GvCusList.Rows[e.RowIndex].FindControl("TxtPhnno") as TextBox;
            TextBox TxtAddress = GvCusList.Rows[e.RowIndex].FindControl("TxtAddress") as TextBox;
            TextBox TxtEmail = GvCusList.Rows[e.RowIndex].FindControl("TxtEmail") as TextBox;

            if (conn.State.ToString() == "Closed")
            {
                conn.Open();
            }

            string sql = " EXEC [CusReg].[dbo].[procCusListWithEdit] 1,'','" + LblCusIDD.Text.Trim() + "','" + TxtName.Text.Trim() + "','" + TxtPhnno.Text.Trim() + "','" + TxtAddress.Text.Trim() + "','" + TxtEmail.Text.Trim() + "'";

            //updating the record  
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview  
            GvCusList.EditIndex = -1;
            //Call BindGvCusList method for displaying updated data  
            BindGvCusList();
        }
    }
}