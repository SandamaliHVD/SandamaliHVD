﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CusWebApp
{
    public partial class CusRegister : System.Web.UI.Page
    {
        //Connection String from web.config and DB_Connect class File
        SqlConnection conn = DB_Connect.GetConnection();

        //Variable declaring
        static int userid = 0;
        static string url = "CusRegister.aspx";

        //Page load method
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LblUserID.Text = "";
                userid = Convert.ToInt32(Session["UserID"]);

                LblUserID.Text = Convert.ToString(userid);

                if (LblUserID.Text == "" || LblUserID.Text == "0")
                {
                    Server.Transfer("~/Login.aspx?url=" + url + "", true);
                }

                if (Session["UserID"].ToString() == null)
                {
                    Server.Transfer("~/Login.aspx?url=" + url + "", true);
                }
                LblSaveMsg.Text = "";
            }
        }

        //Save button click event
        protected void BtnSave_Click(object sender, EventArgs e)
        {
            LblSaveMsg.Text = "";
            //the IF condition for check all the textboxes
            if (TxtName.Text.Trim() != "" && TxtPhnno.Text.Trim() != "0" && TxtAddress.Text.Trim() != "" && TxtEmail.Text.Trim() != "")
            {
                //Save data in database 
                if (conn.State.ToString() == "Closed")
                {
                    conn.Open();
                }
                string sql = " EXEC [CusReg].[dbo].[procCusReg] 1,'','','" + TxtName.Text.Trim() + "','" + TxtPhnno.Text.Trim() + "','" + TxtAddress.Text.Trim() + "','" + TxtEmail.Text.Trim() + "' ";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                conn.Close();

                TxtName.Text = "";
                TxtPhnno.Text = "";
                TxtAddress.Text = "";
                TxtEmail.Text = "";

                LblSaveMsg.Text = "Successfully Saved.";
            }
        }

        //Refresh button click event
        protected void BtnReset_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }
    }
}