﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentMSAPI.Models;
using StudentMSAPI.Models.Dtos;
using StudentMSAPI.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentMSAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : Controller
    {
        private readonly IStudentRepository _studentRepo;
        private readonly IMapper _mapper;

        public StudentsController(IStudentRepository studentRepo, IMapper mapper)
        {
            _studentRepo = studentRepo;
            _mapper = mapper;
        }

        /// <summary>
        /// Get list of Students.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetStudents()
        {
            var objList = _studentRepo.GetStudents();
            var objDto = new List<StudentDto>();
            foreach (var obj in objList)
            {
                objDto.Add(_mapper.Map<StudentDto>(obj));
            }
            return Ok(objDto);
        }

        /// <summary>
        /// Get individual Student
        /// </summary>
        /// <param name="studentId">The ID of the student</param>
        /// <returns></returns>
        [HttpGet("{studentId:int}", Name = "GetStudent")]
        public IActionResult GetStudent(int studentId)
        {
            var obj = _studentRepo.GetStudent(studentId);
            if (obj == null)
            {
                return NotFound();
            }
            var objDto = _mapper.Map<StudentDto>(obj);
            return Ok(objDto);
        }

        /// <summary>
        /// Insert Students
        /// </summary>
        /// <param name="studentDto"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult CreateStudent([FromBody] StudentDto studentDto)
        {
            if (studentDto == null)
            {
                return BadRequest(ModelState);
            }

            if (_studentRepo.StudentExists(studentDto.FirstName))
            {
                ModelState.AddModelError("", "Student Exists!");
                return StatusCode(404, ModelState);
            }
             
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var studentObj = _mapper.Map<Student>(studentDto);
            
            if(!_studentRepo.CreateStudent(studentObj))
            {
                ModelState.AddModelError("", $"Something went wrong when saving the record{studentObj.FirstName}");
                return StatusCode(500, ModelState);
            }

            //return Ok();
            //Created At Route method is better then Ok()
            return CreatedAtRoute("GetStudent", new { studentId = studentObj.StudentId }, studentObj);
        }

        /// <summary>
        /// Update Student
        /// </summary>
        /// <param name="studentId">The ID of the student</param>
        /// <param name="studentDto"></param>
        /// <returns></returns>
        [HttpPatch("{studentId:int}", Name = "UpdateStudent")]
        public IActionResult UpdateStudent(int studentId, [FromBody] StudentDto studentDto)
        {
            if (studentDto == null || studentId != studentDto.StudentId)
            {
                return BadRequest(ModelState);
            }

            var studentObj = _mapper.Map<Student>(studentDto);

            if (!_studentRepo.UpdateStudent(studentObj))
            {
                ModelState.AddModelError("", $"Something went wrong when saving the record{studentObj.FirstName}");
                return StatusCode(500, ModelState);
            }

            return NoContent();
        }

        /// <summary>
        /// Delete Student
        /// </summary>
        /// <param name="studentId">The ID of the student</param>
        /// <returns></returns>
        [HttpDelete("{studentId:int}", Name = "DeleteStudent")]
        public IActionResult DeleteStudent(int studentId)
        {
            if (!_studentRepo.StudentExists(studentId))
            {
                return NotFound();
            }

            var studentObj = _studentRepo.GetStudent(studentId);

            if (!_studentRepo.DeleteStudent(studentObj))
            {
                ModelState.AddModelError("", $"Something went wrong when deleting the record{studentObj.FirstName}");
                return StatusCode(500, ModelState);
            }

            return NoContent();
        } 
    }
}
