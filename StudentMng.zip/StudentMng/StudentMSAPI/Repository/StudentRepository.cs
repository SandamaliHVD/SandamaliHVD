﻿using StudentMSAPI.Data;
using StudentMSAPI.Models;
using StudentMSAPI.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentMSAPI.Repository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly ApplicationDbContext _db;

        public StudentRepository(ApplicationDbContext db)
        {
            _db = db;
        } 

        public bool CreateStudent(Student student)
        {
            _db.Students.Add(student);
            return Save();
        }

        public bool DeleteStudent(Student student)
        {
            _db.Students.Remove(student);
            return Save();
        }

        public Student GetStudent(int studentId)
        {
            return _db.Students.FirstOrDefault(a => a.StudentId == studentId);
        }

        public ICollection<Student> GetStudents()
        {
            return _db.Students.OrderBy(a => a.FirstName).ToList();
        }

        public bool Save()
        {
            return _db.SaveChanges() >= 0 ? true : false;
        }

        public bool StudentExists(string firstname)
        {
            bool value = _db.Students.Any(a => a.FirstName.ToLower().Trim() == firstname.ToLower().Trim());
            return value;
        }

        public bool StudentExists(int id)
        {
            return _db.Students.Any(a => a.StudentId == id);
        }

        public bool UpdateStudent(Student student)
        {
            _db.Students.Update(student);
            return Save(); 
        }
    }
}
