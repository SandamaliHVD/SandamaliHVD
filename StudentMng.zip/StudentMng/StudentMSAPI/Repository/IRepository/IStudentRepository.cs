﻿using StudentMSAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentMSAPI.Repository.IRepository
{
    public interface IStudentRepository
    {
        ICollection<Student> GetStudents();

        Student GetStudent(int studentId);
        bool StudentExists(string firstname);
        bool StudentExists(int id);
        bool CreateStudent(Student student);
        bool UpdateStudent(Student student);
        bool DeleteStudent(Student student);
        bool Save();
    }
}
