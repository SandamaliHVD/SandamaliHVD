﻿using AutoMapper;
using StudentMSAPI.Models;
using StudentMSAPI.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentMSAPI.StudentMapper
{
    public class StudentMappings : Profile
    {
        public StudentMappings()
        {
            CreateMap<Student, StudentDto>().ReverseMap();
        }
    }
}
