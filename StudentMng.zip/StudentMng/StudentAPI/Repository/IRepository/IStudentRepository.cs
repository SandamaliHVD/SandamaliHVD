﻿using StudentAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentAPI.Repository.IRepository
{
    public interface IStudentRepository
    {
        ICollection<Student> GetStudents();

        Student GetStudent(string StudentId);
        bool StudentExists(string firstname);
        bool StudentExists(int id);
        bool CreateStudent(Student student);
        bool UpdateStudent(Student student);
        bool Save();
    }
}
