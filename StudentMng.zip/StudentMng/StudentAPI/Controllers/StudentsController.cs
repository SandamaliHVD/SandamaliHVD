﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentAPI.Models.Dtos;
using StudentAPI.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : Controller
    {
        private IStudentRepository _studentRepo;
        private readonly IMapper _mapper;

        public StudentsController(IStudentRepository studentRepo, IMapper mapper)
        {
            _studentRepo = studentRepo;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult GetStudents()
        {
            var objList = _studentRepo.GetStudents();
            var objDto = new List<StudentDto>();
            foreach (var obj in objList)
            {
                objDto.Add(_mapper.Map<StudentDto>(obj));
            }
            return Ok(objDto);
        }

        [HttpGet("{studentId:string}")]
        public IActionResult GetStudent(string studentId)
        {
            var obj = _studentRepo.GetStudent(studentId);
            if(obj == null)
            {
                return NotFound();
            }
            var objDto = _mapper.Map<StudentDto>(obj);
            return Ok(objDto);
        }

        //[HttpPost]
        //public IActionResult CreateStudent([FromBody] StudentDto studentDto)
        //{
        //    if (studentDto == null)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    if(_studentRepo.StudentExists(studentDto.FirstName))
        //    {
        //        ModelState.AddModelError("", "Student Exists");
        //    }
        //    return ;
        //}
    }
}
